<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Welcome to CodeIgniter 4 + React.js!</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<style> .navbar{margin-bottom: 20px;} </style>
</head>
<body>
<div class="container" style="padding:20px;">
	<h1 style="text-align:center;">
		<a href="/employee"> Full Stack - Laravel 8 & React Hooks </a>
	</h1>
	<hr>

  <div id="payment"></div>
  <script src="/js/app.js"></script>

</div>
</body>
</html>
<?php /**PATH /var/www/html/laravel-react/pyreact/resources/views/test.blade.php ENDPATH**/ ?>